import pygame
from enemy import Enemy
from towers import Towers
from buttons import Buttons
from rounds import Rounds

sc=pygame.display.set_mode((1230,1000))

pygame.init()
pygame.font.init()
Clock=pygame.time.get_ticks()

#images
map=pygame.image.load("tower defanse/map.png")
towers_menu=pygame.image.load("tower defanse/towers menu.png")
#buttons images
cancle_image=pygame.image.load("tower defanse/other buttons/delete-button.png")
can_upgrade_image=pygame.image.load("tower defanse/other buttons/can upgrade.png")
cant_upgrade_image=pygame.image.load("tower defanse/other buttons/cant upgrade.png")
#towers images
fire_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower.png").convert_alpha())
lagandary_img=pygame.image.load("tower defanse/towers and enemyis/lagandary img.png").convert_alpha()

ice_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower.png").convert_alpha())
epic_img=pygame.image.load("tower defanse/towers and enemyis/epic img.png").convert_alpha()

poisen_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower.png").convert_alpha())
rare_img=pygame.image.load("tower defanse/towers and enemyis/rare img.png").convert_alpha()

boom_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower.png").convert_alpha())
common_img=pygame.image.load("tower defanse/towers and enemyis/cammon img.png").convert_alpha()

money_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/bank tower images/bank tower.png").convert_alpha())
money_tower_icon=pygame.transform.scale(pygame.image.load("tower defanse/coin.png").convert_alpha(),(80,80))

#money heart next round images
money_img=pygame.image.load("tower defanse/coin.png").convert_alpha()
heart_img=pygame.image.load("tower defanse/heart.png").convert_alpha()
next_round_img=pygame.image.load("tower defanse/other buttons/next round.png").convert_alpha()
fast_forward_on_img=pygame.transform.scale(pygame.image.load("tower defanse/other buttons/fast forward on.png").convert_alpha(),(100,100))
fast_forward_off_img=pygame.transform.scale(pygame.image.load("tower defanse/other buttons/fast forward off.png").convert_alpha(),(100,100))
restart_img=pygame.transform.scale2x(pygame.image.load("tower defanse/other buttons/restart.png").convert_alpha())
main_img=pygame.transform.scale2x(pygame.image.load("tower defanse/other buttons/main button.png").convert_alpha())
sell_img=pygame.image.load("tower defanse/other buttons/sell button.png").convert_alpha()
blank_image=pygame.image.load("tower defanse/blank image.png").convert_alpha()
#enemyis images
red_ballon=pygame.image.load("tower defanse/towers and enemyis/base ballon.png").convert_alpha()

#main menu
start_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/start button.png").convert_alpha(),(300,300))
tutorial_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/tut button.png").convert_alpha(),(300,300))
quit_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/quit button.png").convert_alpha(),(300,300))
back_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/back button.png").convert_alpha(),(300,300))
easy_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/easy button.png").convert_alpha(),(300,300))
medium_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/medium button.png").convert_alpha(),(300,300))
hard_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/hard button.png").convert_alpha(),(300,300))
check_img=pygame.transform.scale2x(pygame.image.load("tower defanse/other buttons/check-button.png").convert_alpha())
click_sound=pygame.mixer.Sound("tower defanse/main menu/button sound.mp3")
#game veriboles
placeing=False
placeing_lagandary=False
placeing_epic=False
placeing_rare=False
placeing_common=False
placeing_money=False
selected_tower=None
to_spawn=0
level_started=False
game_over="main"
forward=True



#tastks

#funcins



def draw_text(text,font,x,y,color):
    new_text=font.render(text,True,color)
    sc.blit(new_text,(x,y))
def create_towers(mouse_pos,type,tower_type):
    global paths
    global placeing_lagandary,placeing,placeing_epic,placeing_rare,placeing_common,new_tower,sc,cost_common,cost_rare,cost_epic,cost_legandry,cost_money
    mouse_tile_x= a//88
    mouse_tile_y= b//88
    if path1.collidepoint(a,b) or path2.collidepoint(a,b) or path3.collidepoint(a,b) or path4.collidepoint(a,b) or path5.collidepoint(a,b) or path6.collidepoint(a,b) or path7.collidepoint(a,b) or path8.collidepoint(a,b):
        pass
    else:
        space_is_free=True
        for new_tower in towers_group:
                if (mouse_tile_x,mouse_tile_y)==(new_tower.tile_x,new_tower.tile_y):
                        space_is_free=False
        if space_is_free==True:
                    buy=False
                    if tower_type=="fire tower" and rounds.money>=cost_legandry:
                      buy=True
                      rounds.money-=cost_legandry
                    if tower_type=="ice tower" and rounds.money>=cost_epic:
                      buy=True
                      rounds.money-=cost_epic
                    if tower_type=="poisen tower" and rounds.money>=cost_rare:
                      buy=True
                      rounds.money-=cost_rare
                    if tower_type=="boom tower" and rounds.money>=cost_common:
                      buy=True
                      rounds.money-=cost_common
                    if tower_type=="money tower" and rounds.money>=cost_money:
                       buy=True
                       rounds.money-=cost_money
                    if buy==True:
                      new_tower=Towers(mouse_tile_x,mouse_tile_y,type,sc,5,tower_type)
                      towers_group.add(new_tower)
                    placeing_epic=False
                    placeing_lagandary=False
                    placeing_common=False
                    placeing_rare=False
                    placeing_money=False
                    placeing=False
                    


def select_tower(mouse_pos):
    mouse_tile_x= a//88
    mouse_tile_y= b//88

    for tower in towers_group:
        if (tower.tile_x,tower.tile_y) == (mouse_tile_x,mouse_tile_y):
            return tower

def clear_selection():
    for tower in towers_group:
        tower.selected = False


      
      


#enemy class
waypoints=[(-5,300),(930,300),(930,70),(670,70),(670,660),(360,660),(130,660),(130,920),(400,920),(400,-5)]
path1=pygame.Rect(0,250,983,110)
path2=pygame.Rect(880,32,100,250)
path3=pygame.Rect(600,0,350,112)
path4=pygame.Rect(600,12,120,700)
path5=pygame.Rect(90,610,520,100)
path6=pygame.Rect(90,610,100,400)
path7=pygame.Rect(90,870,355,100)
path8=pygame.Rect(350,0,100,900)




#create sprite group for squares
enemyis = pygame.sprite.Group()
enemy_images={
    "base":pygame.image.load("tower defanse/towers and enemyis/base ballon.png").convert_alpha(),
    "fast":pygame.image.load("tower defanse/towers and enemyis/yellow ballon.png").convert_alpha(),
    "strong":pygame.image.load("tower defanse/towers and enemyis/lead ballon.png").convert_alpha(),
    "regane":pygame.image.load("tower defanse/towers and enemyis/ballons images/regane ballon 1.png").convert_alpha(),
    "boss":pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boss ballon 1.png").convert_alpha()
}

#towers class
main_tower=Towers(10,10,ice_tower,0,0,0)
towers_group=pygame.sprite.Group()
#Round class
rounds=Rounds()
rounds.process_enemyis()

#buttons class
upgrade_button=Buttons(1000,691,True,can_upgrade_image)
cancle_button=Buttons(1000,591,True,cancle_image)
legandary_tower=Buttons(1024,110,True,lagandary_img)
epic_tower=Buttons(1024,200,True,epic_img)
rare_tower=Buttons(1024,285,True,rare_img)
common_tower=Buttons(1024,362,True,common_img)
money_tower_button=Buttons(1020,450,True,blank_image)
next_round=Buttons(1130,691,True,next_round_img)
fast_forward=Buttons(1130,591,False,fast_forward_off_img)
sell_button=Buttons(1130,780,True,sell_img)
main_button=Buttons((1230-300)//2,750,True,main_img)
im_sure=Buttons((1230-300)//2-130,500,True,check_img)
#main menu bottons
start_button=Buttons((1230-300)//2,(1000-600)//2,True,start_img)
tutorial_button=Buttons(900,650,True,tutorial_img)
quit_button=Buttons(10,650,True,quit_img)
back_button=Buttons((1230-300)//2,650,True,back_img)
easy_button=Buttons(900,650,True,easy_img)
medium_button=Buttons((1230-300)//2,650,True,medium_img)
hard_button=Buttons(30,650,True,hard_img)
#fonts and text
font=pygame.font.SysFont("Consolas",30,bold=True)
big_font=pygame.font.SysFont("Consolas",60,bold=True)
giant_font=pygame.font.SysFont("Consolas",220,bold=True)
#main loop
#costs
cost_common=0
cost_rare=0
cost_epic=0
cost_legandry=0
cost_money=0
run=True
while run:
    sc.fill("aqua")
    sc.blit(map,(0,0))
    sc.blit(towers_menu,(1000,0))
    fast_forward.draw(sc)
    #blit coin and heart
    sc.blit(heart_img,(0,0))
    sc.blit(money_img,(130,0))

    #cost of staff
    draw_text(str(cost_legandry),big_font,1130,120,(0,255,0))
    draw_text(str(cost_epic),big_font,1130,210,(0,255,0))
    draw_text(str(cost_rare),big_font,1130,300,(0,255,0))
    draw_text(str(cost_common),big_font,1130,382,(0,255,0))
    draw_text(str(cost_money),big_font,1130,465,(0,255,0))

    
    
    if game_over==False:
        sc.blit(money_tower_icon,(1030,450))
        #draw groups
        enemyis.draw(sc)
        for tower in towers_group:
           tower.draw(sc)
        #update groups
        enemyis.update(rounds)
        towers_group.update(enemyis,rounds,sc)
        if rounds.health<=0:
            game_over=True
        
        #back to main
        back_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/back button.png").convert_alpha(),(100,100))
        back_button=Buttons(1130,890,True,back_img)
        if back_button.draw(sc):
            game_over="making sure"
            click_sound.play()
        
            
            cancle_image=pygame.transform.scale2x(pygame.image.load("tower defanse/other buttons/delete-button.png"))
            cancle_button=Buttons((1230-300)//2+130,500,True,cancle_image)



        #hight light selected tower
        if selected_tower:
            selected_tower.selected=True
            if selected_tower.tower_type=="fire tower" and rounds.money>cost_legandry or selected_tower.tower_type=="ice tower" and rounds.money>cost_epic or selected_tower.tower_type=="poisen tower" and rounds.money>cost_rare or selected_tower.tower_type=="boom tower" and rounds.money>cost_common or selected_tower.tower_type=="money tower" and rounds.money>cost_money:
                upgrade_button.image=can_upgrade_image
            else:
                upgrade_button.image=cant_upgrade_image

            if selected_tower.upgrade_tower < 2:
             if upgrade_button.draw(sc):
                selected_tower.upgrade(rounds,cost_common,cost_rare,cost_epic,cost_legandry,cost_money)
            if sell_button.draw(sc):
                if selected_tower.tower_type=="fire tower":
                    rounds.money+=cost_legandry
                if selected_tower.tower_type=="ice tower":
                    rounds.money+=cost_epic
                if selected_tower.tower_type=="poisen tower":
                    rounds.money+=cost_rare
                if selected_tower.tower_type=="boom tower":
                    rounds.money+=cost_common
                if selected_tower.tower_type=="money tower":
                    rounds.money+=cost_money
                selected_tower.kill()
                tower.selected = None
                selected_tower=None
        #spawn enemeis
        if to_spawn<=rounds.ballon_timer:
            to_spawn+=1
        else:
          if len(rounds.enemy_list) > rounds.spawend_enemeis and level_started==True:
            enemy_type = rounds.enemy_list[rounds.spawend_enemeis]
            enemy = Enemy(enemy_type, enemy_images, waypoints,sc,rounds)
            enemyis.add(enemy)
            rounds.spawend_enemeis += 1
            last_enemy_spawn = pygame.time.get_ticks()
          to_spawn=0
        

        if rounds.check_if_level_complete()==True:
            rounds.money+=100
            level_started=False
            to_spawn=0
        
        #draw text
        if level_started==False:
         if next_round.draw(sc):
            level_started=True
         draw_text("next",font,1140,701,"yellow")
         draw_text("round",font,1140,741,"yellow")


        draw_text(f"round:{round(rounds.level)}",font,10,70,"green")
        





        #button draw
        if legandary_tower.draw(sc) and rounds.money>=cost_legandry:
            placeing=True
            placeing_lagandary=True
            placeing_epic=False
            placeing_common=False
            placeing_rare=False
            placeing_money=False
        if epic_tower.draw(sc) and rounds.money>=cost_epic:
            placeing=True
            placeing_epic=True 
            placeing_lagandary=False
            placeing_common=False
            placeing_rare=False
            placeing_money=False
        if rare_tower.draw(sc) and rounds.money>=cost_rare:
            placeing=True
            placeing_rare=True 
            placeing_lagandary=False
            placeing_epic=False
            placeing_common=False
            placeing_money=False
        if common_tower.draw(sc) and rounds.money>=cost_common:
            placeing=True
            placeing_common=True 
            placeing_lagandary=False
            placeing_epic=False
            placeing_rare=False
            placeing_money=False
        if money_tower_button.draw(sc) and rounds.money>=cost_money:
            placeing=True
            placeing_common=False
            placeing_lagandary=False
            placeing_epic=False
            placeing_rare=False
            placeing_money=True
        if placeing:
         tower_show=pygame.mouse.get_pos()
         cancle_image=pygame.image.load("tower defanse/other buttons/delete-button.png")
         cancle_button=Buttons(1000,591,True,cancle_image)
         if cancle_button.draw(sc):
            placeing=False
         if tower_show[0]<1000:
            if placeing_lagandary:
              sc.blit(fire_tower,(tower_show[0]-40,tower_show[1]-40))
            if placeing_epic:
                sc.blit(ice_tower,(tower_show[0]-40,tower_show[1]-40))
            if placeing_rare:
                sc.blit(poisen_tower,(tower_show[0]-40,tower_show[1]-40))
            if placeing_common:
                sc.blit(boom_tower,(tower_show[0]-40,tower_show[1]-40))
            if placeing_money:
                sc.blit(money_tower,(tower_show[0]-40,tower_show[1]-40))


        if fast_forward.draw(sc):
            if forward==True:
                fast_forward.image=fast_forward_on_img
                rounds.game_speed = 3
                pygame.time.delay(100)
                forward=False
            else:
                fast_forward.image=fast_forward_off_img
                rounds.game_speed = 2
                pygame.time.delay(100)
                forward=True
        #draw text
        draw_text(str(rounds.health),font,50,10,(220,0,0))
        draw_text(str(rounds.money),font,190,10,"yellow")
    
    #making sure you want to quit
    if game_over=="making sure":
      draw_text("are you sure you want to quit?",big_font,10,270,(0,255,0))
      if im_sure.draw(sc):
        pygame.mouse.set_pos(500,500)
        game_over="main"
        click_sound.play()
        making_sure=False
      if cancle_button.draw(sc):
        game_over=False


    if game_over==True:
        draw_text("GAME OVER",giant_font,10,300,"red")
        if main_button.draw(sc):
          pygame.mouse.set_pos(500,500)
          game_over="main"
          click_sound.play()

    if game_over=="main":
            if start_button.draw(sc):
                click_sound.play()
                rounds=Rounds()
                rounds.process_enemyis()
                game_outcome=0
                pygame.time.delay(350)
                level_started=False
                game_over="hard"
                selected_tower=None
                placeing=False
                to_spawn=0
                towers_group.empty()
                enemyis.empty()
                sc.fill("aqua")
                sc.blit(map,(0,0))
                sc.blit(towers_menu,(1000,0))
                fast_forward.draw(sc)
            if tutorial_button.draw(sc):
                click_sound.play()
                game_over="tutorial"
            if quit_button.draw(sc):
                click_sound.play()
                quit()
    if game_over=="tutorial":
        back_img=pygame.transform.scale(pygame.image.load("tower defanse/main menu/back button.png").convert_alpha(),(300,300))
        back_button=Buttons((1230-300)//2,650,True,back_img)
        sc.blit(lagandary_img,(1000,600))
        if back_button.draw(sc):
            click_sound.play()
            game_over="main"
        draw_text("how to play",big_font,500,100,"red")
        draw_text("1.click on a icon and place your tower",font,500,170,"blue")
        draw_text("2.you can upgrade your tower",font,500,220,"blue")
        draw_text("by clicking on the tower",font,500,270,"blue")
        draw_text("and clicking on the arrow button",font,500,320,"blue")
        draw_text("3.to start the next round",font,500,370,"blue")
        draw_text("click on the next round button",font,500,420,"blue")
        draw_text("icon = ",big_font,780,620,"blue")
        draw_text("mission",big_font,100,100,(0,255,0))
        draw_text("try to survive",font,100,170,"gray")
        draw_text("as long as you can",font,100,230,"gray")
        draw_text("tips",big_font,100,400,"yellow")
        draw_text("1.place your towers",font,100,470,"orange")
        draw_text("close to the track",font,100,530,"orange")
        draw_text("2.think what are you",font,100,590,"orange")
        draw_text("going to buy next",font,100,650,"orange")
        draw_text("3.look at your money and hearts",font,100,710,"orange")
        draw_text("at the top right",font,100,770,"orange")
        draw_text("4.as you get further",font,100,820,"orange")
        draw_text("the ballons get stronger",font,100,870,"orange")
    
    if game_over=="hard":
        if easy_button.draw(sc):
            cost_common=200
            cost_rare=100
            cost_epic=100
            cost_legandry=100
            cost_money=150
            rounds.money=700
            rounds.health=200
            click_sound.play()
            game_over=False
        if medium_button.draw(sc):
            cost_common=250
            cost_rare=100
            cost_epic=150
            cost_legandry=100
            cost_money=150
            rounds.money=550
            rounds.health=150
            click_sound.play()
            game_over=False
        if hard_button.draw(sc):
            cost_common=300
            cost_rare=150
            cost_epic=200
            cost_legandry=150
            cost_money=200
            click_sound.play()
            game_over=False


    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            run=False
            quit()
        if event.type==pygame.MOUSEBUTTONDOWN and event.button==1:
            a,b=pygame.mouse.get_pos()
            if a<900 and b<1000:
              selected_tower = None
              clear_selection()
              if placeing:
                if placeing_lagandary:
                 create_towers((a,b),fire_tower,"fire tower")
                if placeing_epic:
                    create_towers((a,b),ice_tower,"ice tower")
                if placeing_rare:
                    create_towers((a,b),poisen_tower,"poisen tower")
                if placeing_common:
                    create_towers((a,b),boom_tower,"boom tower")
                if placeing_money:
                    create_towers((a,b),money_tower,"money tower")
              else:
                selected_tower = select_tower((a,b))




    pygame.display.update()
        















