import pygame
from pygame.math import Vector2
from constenst import ENEMY_STATS,epic_tower_upgrade,rare_tower_upgrade
import random
from rounds import Rounds

class Enemy(pygame.sprite.Sprite):

    def __init__(self,enemy_type,images,waypoints,sc,rounds):
      pygame.sprite.Sprite.__init__(self)
      self.sc=sc
      self.image = images.get(enemy_type)
      self.type=enemy_type
      self.waypoints=waypoints
      self.pos=Vector2(self.waypoints[0])
      self.target_waypoint=1
      self.rect = self.image.get_rect()
      self.rect.center = self.pos
      self.health=ENEMY_STATS[enemy_type].get("health") + rounds.increse
      self.speed=ENEMY_STATS[enemy_type].get("speed") + rounds.increse
      self.temp=0
      self.animay=0
      self.regane=False
      self.poisened=False
      self.times_poisend=0
      self.tick_timer=0
      self.poisen_level=0
      if enemy_type=="regane":
        self.regane=True
        self.regdelay=ENEMY_STATS[enemy_type].get("ability")
        self.regtimer=0
    


    def update(self,rounds):
      if self.poisened==True:
        self.poisend()
      self.move(rounds)
      self.enemy_health(rounds)
      if self.regane==True:
        self.reganes()
    
    def draw(self,sc):
      surface.blit(self.image, self.rect)
    
    def load_images(self,images):
      if self.temp<=self.delay:
        self.temp+=1
      else:
        self.animay+=1
        self.temp=0
      if self.animay>=len(images):
        self.animay=0

      self.image=images[self.animay]
    
    def enemy_health(self,re):
      if self.health<=0:
        re.killed_enemeis+=1
        re.money+=1
        pop_ballon=pygame.mixer.Sound("tower defanse/pop ballon.mp3")
        pop_ballon.play()
        self.kill()
    

    def reganes(self):
      if self.health!=ENEMY_STATS["regane"].get("health"):
        if self.regtimer<self.regdelay:
          self.regtimer+=1
        else:
          if self.health+5<=ENEMY_STATS["regane"].get("health"):
            self.health+=5
      else:
          self.regtimer=0

    def move(self,rounds):
      #define a target waypoint
      self.target=Vector2(self.waypoints[self.target_waypoint])
      self.movement=self.target - self.pos

      if self.type=="base":
        if self.poisened==False:
          if self.health>10:
            red=pygame.image.load("tower defanse/towers and enemyis/base ballon.png")
            red1=pygame.image.load("tower defanse/towers and enemyis/ballons images/red ballon 1.png")
            red2=pygame.image.load("tower defanse/towers and enemyis/ballons images/red ballon 2.png")
            red3=pygame.image.load("tower defanse/towers and enemyis/ballons images/red ballon 3.png")
            self.delay=10
            self.load_images((red1,red2,red3,red2,red1,red))
          else:
            halfred1=pygame.image.load("tower defanse/towers and enemyis/ballons images/half ballon/red ballon  half health 1.png")
            halfred2=pygame.image.load("tower defanse/towers and enemyis/ballons images/half ballon/red ballon  half health 2.png")
            halfred3=pygame.image.load("tower defanse/towers and enemyis/ballons images/half ballon/red ballon  half health 3.png")
            self.delay=10
            self.load_images((halfred1,halfred2,halfred3,halfred2,halfred1))
        else:
          if self.health>10:
            red1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend red ballon 1.png")
            red2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend red ballon 2.png")
            red3=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend red ballon 3.png")
            self.delay=10
            self.load_images((red1,red2,red3,red2,red1))
          else:
            halfred1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend half red ballon 1.png")
            halfred2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend half red ballon 2.png")
            halfred3=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend half red ballon 3.png")
            self.delay=10
            self.load_images((halfred1,halfred2,halfred3,halfred2,halfred1))
      elif self.type=="fast":
        if self.poisened==False:
          yellow=pygame.image.load("tower defanse/towers and enemyis/yellow ballon.png")
          yellow1=pygame.image.load("tower defanse/towers and enemyis/ballons images/yellow ballon 1.png")
          yellow2=pygame.image.load("tower defanse/towers and enemyis/ballons images/yellow ballon 2.png")
          yellow3=pygame.image.load("tower defanse/towers and enemyis/ballons images/yellow ballon 3.png")
          self.delay=8
          self.load_images((yellow1,yellow2,yellow3,yellow2,yellow1,yellow))
        else:
          yellow1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend yellow ballon 1.png")
          yellow2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend yellow ballon 2.png")
          yellow3=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend yellow ballon 3.png")
          self.delay=8
          self.load_images((yellow1,yellow2,yellow3,yellow2))
      elif self.type=="strong":
        if self.poisened==False:
          if self.health>20:
            lead=pygame.image.load("tower defanse/towers and enemyis/lead ballon.png")
            lead1=pygame.image.load("tower defanse/towers and enemyis/ballons images/lead ballon 1.png")
            lead2=pygame.image.load("tower defanse/towers and enemyis/ballons images/lead ballon 2.png")
            lead3=pygame.image.load("tower defanse/towers and enemyis/ballons images/lead ballon 3.png")
            self.delay=12
            self.load_images((lead1,lead2,lead3,lead2,lead1,lead))
          elif self.health>10 and self.health<=20:
            lead1=pygame.image.load("tower defanse/towers and enemyis/ballons images/0.33 ballon/lead ballon 0.6666 1.png")
            lead2=pygame.image.load("tower defanse/towers and enemyis/ballons images/0.33 ballon/lead ballon 0.6666 2.png")
            lead3=pygame.image.load("tower defanse/towers and enemyis/ballons images/0.33 ballon/lead ballon 0.6666 3.png")
            self.delay=12
            self.load_images((lead1,lead2,lead3,lead2,lead1))
          elif self.health<=10:
            lead1=pygame.image.load("tower defanse/towers and enemyis/ballons images/0.33 ballon/lead ballon 0.3333 1.png")
            lead2=pygame.image.load("tower defanse/towers and enemyis/ballons images/0.33 ballon/lead ballon 0.3333 2.png")
            lead3=pygame.image.load("tower defanse/towers and enemyis/ballons images/0.33 ballon/lead ballon 0.3333 3.png")
            self.delay=12
            self.load_images((lead1,lead2,lead3,lead2,lead1))
        else:
          if self.health>20:
            lead1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 1.png")
            lead2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 2.png")
            lead3=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 3.png")
            self.delay=12
            self.load_images((lead1,lead2,lead3,lead2,lead1))
          elif self.health>10 and self.health<=20:
            lead1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 0.6666 1.png")
            lead2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 0.6666 2.png")
            lead3=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 0.6666 3.png")
            self.delay=12
            self.load_images((lead1,lead2,lead3,lead2,lead1))
          elif self.health<=10:
            lead1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 0.3333 1.png")
            lead2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 0.3333 2.png")
            lead3=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend lead ballon 0.3333 3.png")
            self.delay=12
            self.load_images((lead1,lead2,lead3,lead2,lead1))
      elif self.type=="regane":
        if self.poisened==False:
          if self.health>5:
            regane1=pygame.image.load("tower defanse/towers and enemyis/ballons images/regane ballon 1.png")
            regane2=pygame.image.load("tower defanse/towers and enemyis/ballons images/regane ballon 2.png")
            self.delay=20
            self.load_images((regane1,regane2))
          else:
            regane1=pygame.image.load("tower defanse/towers and enemyis/ballons images/half ballon/half regane ballon 1.png")
            regane2=pygame.image.load("tower defanse/towers and enemyis/ballons images/half ballon/half regane ballon 2.png")
            self.delay=20
            self.load_images((regane1,regane2))
        else:
          if self.health>5:
            regane1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend regane ballon 1.png")
            regane2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend regane ballon 2.png")
            self.delay=20
            self.load_images((regane1,regane2))
          else:
            regane1=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend half regane ballon 1.png")
            regane2=pygame.image.load("tower defanse/towers and enemyis/ballons images/poisend/poisend half regane ballon 2.png")
            self.delay=20
            self.load_images((regane1,regane2))
      elif self.type=="boss":
          if self.health>75:
            boos1=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boss ballon 1.png")
            boos2=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boss ballon 2.png")
            boos3=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boss ballon 3.png")
            boos4=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boss ballon 4.png")
            self.delay=10
            self.load_images((boos1,boos2,boos3,boos4,boos3,boos2,boos1))
          elif self.health>50 and self.health<=75:
            boos1=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon red 1.png")
            boos2=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon red 2.png")
            boos3=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon red 3.png")
            boos4=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon red 4.png")
            self.delay=10
            self.load_images((boos1,boos2,boos3,boos4,boos3,boos2,boos1))
          elif self.health<=50 and self.health>25:
            boos1=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon yellow 1.png")
            boos2=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon yellow 2.png")
            boos3=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon yellow 3.png")
            boos4=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon yellow 4.png")
            self.delay=12
            self.load_images((boos1,boos2,boos3,boos4,boos3,boos2,boos1))
          if self.health<=25:
            boos1=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon green 1.png")
            boos2=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon green 2.png")
            boos3=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon green 3.png")
            boos4=pygame.image.load("tower defanse/towers and enemyis/ballons images/boos ballon/boos ballon green 4.png")
            self.delay=10
            self.load_images((boos1,boos2,boos3,boos4,boos3,boos2,boos1))
        

      #calculate distance to target
      dis=self.movement.length()
      if dis>=(self.speed * rounds.game_speed):
        self.pos+=self.movement.normalize() * (self.speed * rounds.game_speed)
      else:
        if dis!=0:
          self.pos+=self.movement.normalize() * dis
        self.target_waypoint+=1
      
      if self.target_waypoint==10:
        rounds.missed_enemeis+=1
        if self.type=="fast":
         rounds.health-=5
        if self.type=="strong":
         rounds.health-=20
        if self.type=="base":
         rounds.health-=10
        if self.type=="regane":
          rounds.health-=8
        if self.type=="boss":
          rounds.health=0
        self.kill()
        
      self.rect.center=self.pos
      

    def poisend(self):
          if self.tick_timer<60:
            self.tick_timer+=1
          else:
            self.tick_timer=0
            self.health-=self.poisen_level
            self.times_poisend+=1
          if self.times_poisend==3 or self.health<=0:
            self.times_poisend=0
            self.poisened=False

        















