





#Tower Stats
lagandary_tower_upgrade = [{"range": 100, "speed": 25, "damage": 5},{"range": 110, "speed": 20, "damage": 10},{"range": 130, "speed": 15, "damage": 15}]
epic_tower_upgrade = [{"range": 100, "speed": 15, "damage": 2,"ability":10},{"range": 110, "speed": 15, "damage": 3,"ability":15},{"range": 130, "speed": 15, "damage": 7,"ability":20}]
rare_tower_upgrade = [{"range": 110, "speed": 20,"ability":5},{"range": 130, "speed": 20,"ability":6},{"range": 150, "speed": 20,"ability":10}]
common_tower_upgrade = [{"range": 120, "speed": 40, "damage": 10},{"range": 150, "speed": 35, "damage": 10},{"range": 180, "speed": 30, "damage": 15}]
money_tower_upgrade=[100,200,300]
#Enemy Stats
ENEMY_STATS = {
    "base": {
        "health": 20,
        "speed": 2
    },
    "fast": {
        "health": 5,
        "speed": 4
    },
    "strong": {
        "health": 30,
        "speed": 1
    },"regane":{
        "health":10,
        "speed":2,
        "ability":8
    },"boss":{
        "health":100,
        "speed":1,
        }
}

