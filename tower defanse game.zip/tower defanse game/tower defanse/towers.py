import pygame
import math
from constenst import lagandary_tower_upgrade,epic_tower_upgrade,rare_tower_upgrade,common_tower_upgrade,money_tower_upgrade,ENEMY_STATS
class Towers(pygame.sprite.Sprite):

    def __init__(self,tile_x,tile_y,image,Surface,delay,tower_type):
      pygame.sprite.Sprite.__init__(self)
      self.upgrade_tower=0
      self.image = image
      self.tile_x=tile_x
      self.tile_y=tile_y
      self.selected = False
      self.temp=0
      self.animay=0
      self.target = None
      self.tower_type = tower_type
      if tower_type=="fire tower":
        self.range=lagandary_tower_upgrade[0].get("range")
        self.delay=lagandary_tower_upgrade[0].get("speed")
        self.damage=lagandary_tower_upgrade[0].get("damage")
      if tower_type=="ice tower":
        self.range=epic_tower_upgrade[0].get("range")
        self.delay=epic_tower_upgrade[0].get("speed")
        self.damage=epic_tower_upgrade[0].get("damage")
      if tower_type=="poisen tower":
        self.range=rare_tower_upgrade[0].get("range")
        self.delay=rare_tower_upgrade[0].get("speed")
        self.damage=rare_tower_upgrade[0].get("damage")
      if tower_type=="boom tower":
        self.range=common_tower_upgrade[0].get("range")
        self.delay=common_tower_upgrade[0].get("speed")
        self.damage=common_tower_upgrade[0].get("damage")
      self.sc=Surface

      #colcolite center coordints
      self.x=(tile_x + 0.5) * 88
      self.y=(tile_y + 0.5) * 88

      self.rect = self.image.get_rect()
      self.rect.center = (self.x,self.y)
    

    def update(self,enemy_group,rounds,sc):
      self.money_tower_ability(rounds,sc)
      if self.tower_type!="money tower":
        if self.target:
          if self.tower_type == "fire tower":
            if self.upgrade_tower==0:
              fire_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower.png").convert_alpha())
              fire_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/fire tower 1.png").convert_alpha())
              fire_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/fire tower 2.png").convert_alpha())
              fire_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/fire tower 3.png").convert_alpha())
              fire_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/fire tower 4.png").convert_alpha())
              fire_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/fire tower 5.png").convert_alpha())
              self.load_images((fire_tower,fire_tower1,fire_tower2,fire_tower3,fire_tower4,fire_tower5),rounds)
            if self.upgrade_tower==1:
              fire_tower_upgraded_1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/upgraded fire tower 1.png").convert_alpha())
              fire_tower_upgraded_2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/upgraded fire tower 2.png").convert_alpha())
              fire_tower_upgraded_3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/upgraded fire tower 3.png").convert_alpha())
              fire_tower_upgraded_4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/upgraded fire tower 4.png").convert_alpha())
              fire_tower_upgraded_5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/upgraded fire tower 5.png").convert_alpha())
              self.load_images((fire_tower_upgraded_1,fire_tower_upgraded_2,fire_tower_upgraded_3,fire_tower_upgraded_4,fire_tower_upgraded_5),rounds)
            if self.upgrade_tower==2:
              fire_tower_max_1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/max fire tower 1.png").convert_alpha())
              fire_tower_max_3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/max fire tower 3.png").convert_alpha())
              fire_tower_max_4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/max fire tower 4.png").convert_alpha())
              fire_tower_max_5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/max fire tower 5.png").convert_alpha())
              fire_tower_max_8=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower.png").convert_alpha())
              self.load_images((fire_tower_max_1,fire_tower_max_3,fire_tower_max_4,fire_tower_max_5,fire_tower_max_8,fire_tower_max_8),rounds)
          elif self.tower_type == "ice tower":
            if self.upgrade_tower==0:
              ice_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower.png").convert_alpha())
              ice_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/ice tower 1.png").convert_alpha())
              ice_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/ice tower 2.png").convert_alpha())
              ice_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/ice tower 3.png").convert_alpha())
              ice_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/ice tower 4.png").convert_alpha())
              ice_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/ice tower 5.png").convert_alpha())
              self.load_images((ice_tower,ice_tower1,ice_tower2,ice_tower3,ice_tower5),rounds)
            if self.upgrade_tower==1:
              upgraded_ice_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/upgraded ice tower 1.png").convert_alpha())
              upgraded_ice_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/upgraded ice tower 2.png").convert_alpha())
              upgraded_ice_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/upgraded ice tower 3.png").convert_alpha())
              upgraded_ice_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/upgraded ice tower 4.png").convert_alpha())
              upgraded_ice_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/upgraded ice tower 5.png").convert_alpha())
              self.load_images((upgraded_ice_tower1,upgraded_ice_tower2,upgraded_ice_tower3,upgraded_ice_tower4,upgraded_ice_tower5),rounds)
            if self.upgrade_tower==2:
              max_ice_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/max ice tower 1.png").convert_alpha())
              max_ice_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/max ice tower 2.png").convert_alpha())
              max_ice_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/max ice tower 3.png").convert_alpha())
              max_ice_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/max ice tower 4.png").convert_alpha())
              max_ice_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/max ice tower 5.png").convert_alpha())
              self.load_images((max_ice_tower1,max_ice_tower2,max_ice_tower3,max_ice_tower4,max_ice_tower5),rounds)
          elif self.tower_type=="poisen tower":
            if self.upgrade_tower==0:
              poisen_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower.png").convert_alpha())
              poisen_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/poisen tower 1.png").convert_alpha())
              poisen_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/poisen tower 2.png").convert_alpha())
              poisen_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/poisen tower 3.png").convert_alpha())
              poisen_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/poisen tower 4.png").convert_alpha())
              poisen_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/poisen tower 5.png").convert_alpha())
              poisen_tower6=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/poisen tower 6.png").convert_alpha())
              self.load_images((poisen_tower,poisen_tower1,poisen_tower2,poisen_tower3,poisen_tower4,poisen_tower5,poisen_tower6,poisen_tower6),rounds)
            if self.upgrade_tower==1:
              upgraded_poisen_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/upgraded poisen tower 1.png").convert_alpha())
              upgraded_poisen_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/upgraded poisen tower 2.png").convert_alpha())
              upgraded_poisen_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/upgraded poisen tower 3.png").convert_alpha())
              upgraded_poisen_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/upgraded poisen tower 4.png").convert_alpha())
              upgraded_poisen_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/upgraded poisen tower 5.png").convert_alpha())
              self.load_images((upgraded_poisen_tower1,upgraded_poisen_tower2,upgraded_poisen_tower3,upgraded_poisen_tower4,upgraded_poisen_tower5),rounds)
            if self.upgrade_tower==2:
              max_poisen_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/max poisen tower 1.png").convert_alpha())
              max_poisen_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/max poisen tower 2.png").convert_alpha())
              max_poisen_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/max poisen tower 3.png").convert_alpha())
              self.load_images((max_poisen_tower1,max_poisen_tower2,max_poisen_tower3),rounds)
          elif self.tower_type=="boom tower":
            if self.upgrade_tower==0:
              boom_tower=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower.png").convert_alpha())
              boom_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 1.png").convert_alpha())
              boom_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 2.png").convert_alpha())
              boom_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 3.png").convert_alpha())
              boom_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 4.png").convert_alpha())
              boom_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 5.png").convert_alpha())
              boom_tower6=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 6.png").convert_alpha())
              boom_tower7=pygame.transform.scale(pygame.image.load("tower defanse/towers and enemyis/boom tower images/boom tower 7.png").convert_alpha(),(100,100))
              self.load_images((boom_tower,boom_tower1,boom_tower2,boom_tower3,boom_tower4,boom_tower5,boom_tower6,boom_tower7),rounds)
            if self.upgrade_tower==1:
              boom_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 1.png").convert_alpha())
              boom_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 2.png").convert_alpha())
              boom_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 3.png").convert_alpha())
              boom_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 4.png").convert_alpha())
              boom_tower5=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 5.png").convert_alpha())
              boom_tower6=pygame.transform.scale(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 6.png").convert_alpha(),(80,80))
              self.load_images((boom_tower1,boom_tower2,boom_tower3,boom_tower4,boom_tower5,boom_tower6),rounds)
            if self.upgrade_tower==2:
              max_boom_tower1=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/max boom tower 1.png").convert_alpha())
              max_boom_tower2=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/max boom tower 2.png").convert_alpha())
              max_boom_tower3=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/max boom tower 3.png").convert_alpha())
              max_boom_tower4=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/max boom tower 4.png").convert_alpha())
              max_boom_tower6=pygame.transform.scale(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 6.png").convert_alpha(),(80,80))
              self.load_images((max_boom_tower1,max_boom_tower2,max_boom_tower3,max_boom_tower4,max_boom_tower6),rounds)

        else:
          self.pick_target(enemy_group)
    



    def pick_target(self,enemy_group):
      x_dist = 0
      y_dist = 0

      for enemy in enemy_group:
        if enemy.health>0:
          x_dist = enemy.pos[0] - self.x
          y_dist = enemy.pos[1] - self.y
          dist=math.sqrt(x_dist ** 2 + y_dist ** 2)
          if dist<self.range:
            self.target = enemy
            if self.tower_type=="boom tower":
              enemy.health-=self.damage /2
              fired_red_ballon=pygame.image.load("tower defanse/towers and enemyis/ballons images/fired ballon/fired red ballon.png")
              self.target.health-=self.damage / 2
              for _ in range(4):
                self.target.image=fired_red_ballon
              
            
            if self.tower_type=="fire tower" or self.tower_type=="ice tower":
              self.target.health-=self.damage
            
            if self.tower_type!="poisen tower":
              if self.damage>=5 and self.target.health>0:
                  pop_ballon=pygame.mixer.Sound("tower defanse/pop ballon.mp3")
                  pop_ballon.play()
            if self.tower_type=="ice tower" and self.upgrade_tower==2:
              if self.target.speed>=1:
                self.target.speed-=0.5
            if self.tower_type=="poisen tower":
                self.target.poisened=True
                self.target.poisen_level=rare_tower_upgrade[self.upgrade_tower].get("ability")
            if self.tower_type!="boom tower":
              break

      

    def load_images(self,images,rounds):
      if self.temp<=(self.delay / rounds.game_speed):
        self.temp+=1
      else:
        self.animay+=1
        self.temp=0
      if self.animay>=len(images):
        self.target = None
        self.animay=0
      
      self.image=images[self.animay]

    def upgrade(self,rounds,cost_common,cost_rare,cost_epic,cost_legandry,cost_money):
        if self.tower_type=="fire tower" and rounds.money>=cost_legandry:
          rounds.money-=cost_legandry
          self.upgrade_tower+=1
          self.range=lagandary_tower_upgrade[self.upgrade_tower].get("range")
          self.delay=lagandary_tower_upgrade[self.upgrade_tower].get("speed")
          self.damage=lagandary_tower_upgrade[self.upgrade_tower].get("damage")
          if self.upgrade_tower==1:
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/upgraded fire tower 1.png").convert_alpha())
          if self.upgrade_tower==2:
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/fire tower images/max fire tower 1.png").convert_alpha())
        if self.tower_type=="ice tower"  and rounds.money>=cost_epic:
            self.upgrade_tower+=1
            rounds.money-=cost_epic
            self.range=epic_tower_upgrade[self.upgrade_tower].get("range")
            self.delay=epic_tower_upgrade[self.upgrade_tower].get("speed")
            self.damage=epic_tower_upgrade[self.upgrade_tower].get("damage")
            if self.upgrade_tower==1:
              self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/upgraded ice tower 1.png").convert_alpha())
            if self.upgrade_tower==2:
              self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/ice tower images/max ice tower 1.png").convert_alpha())
        if self.tower_type=="poisen tower"  and rounds.money>=cost_rare:
          self.upgrade_tower+=1
          rounds.money-=cost_rare
          self.range=rare_tower_upgrade[self.upgrade_tower].get("range")
          self.delay=rare_tower_upgrade[self.upgrade_tower].get("speed")
          self.damage=rare_tower_upgrade[self.upgrade_tower].get("damage")
          if self.upgrade_tower==1:
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/upgraded poisen tower 1.png").convert_alpha())
          if self.upgrade_tower==2:
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/poisen tower images/max poisen tower 1.png").convert_alpha())
        if self.tower_type=="boom tower"  and rounds.money>=cost_common:
          self.upgrade_tower+=1
          rounds.money-=cost_common
          self.range=common_tower_upgrade[self.upgrade_tower].get("range")
          self.delay=common_tower_upgrade[self.upgrade_tower].get("speed")
          self.damage=common_tower_upgrade[self.upgrade_tower].get("damage")
          if self.upgrade_tower==1:  
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/upgraded boom tower 1.png").convert_alpha())
          if self.upgrade_tower==2:
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/boom tower images/max boom tower 1.png").convert_alpha())
        if self.tower_type=="money tower" and rounds.money>=cost_money:
          self.upgrade_tower+=1
          rounds.money-=cost_money
          if self.upgrade_tower==1:  
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/bank tower images/bank tower 2.png").convert_alpha())
          if self.upgrade_tower==2:
            self.image=pygame.transform.scale2x(pygame.image.load("tower defanse/towers and enemyis/bank tower images/bank tower 3.png").convert_alpha())
        #upgrade range circle
        if self.tower_type!="money tower":
          range_surface = pygame.Surface((self.range * 2, self.range * 2),pygame.SRCALPHA)


    def draw(self, surface):
      surface.blit(self.image, self.rect)  # Draw the tower image
      if self.tower_type!="money tower":
        # Create a surface with alpha channel for the range circle
        range_surface = pygame.Surface((self.range * 2, self.range * 2),pygame.SRCALPHA)
        if self.selected:
         self.Circle=pygame.draw.circle(range_surface, (255, 255, 255, 128), (self.range, self.range), self.range)

        # Blit the circle surface on top of the tower image
        surface.blit(range_surface, (self.x - self.range, self.y - self.range))
    
    def money_tower_ability(self,rounds,sc):
      if self.tower_type=="money tower":
        if (rounds.killed_enemeis+rounds.missed_enemeis)==len(rounds.enemy_list):
          rounds.money+=money_tower_upgrade[self.upgrade_tower]
          font=pygame.font.SysFont("Consolas",30,bold=True)
          money_got=font.render(f"+{money_tower_upgrade[self.upgrade_tower]}$",True,"yellow")
          sc.blit(money_got,(self.tile_x * 89,self.tile_y * 88+50))

    

