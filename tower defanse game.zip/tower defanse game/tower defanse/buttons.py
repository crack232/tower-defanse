import pygame




class Buttons():

    def __init__(self,x,y,single_click,image):
        self.image=image
        self.rect=image.get_rect()
        self.rect.topleft=x,y
        self.clicked=False
        self.single_click=single_click
    

    def draw(self,surface):
        actine=False
        mouse_pos=pygame.mouse.get_pos()

        if self.rect.collidepoint(mouse_pos):
            if pygame.mouse.get_pressed()[0]==1 and self.clicked==False:
              actine=True
              #if button is a singele click type, then set click to True
              if self.single_click:
                self.clicked=True
        
        if pygame.mouse.get_pressed()[0]==0:
            self.clicked=False
        

        surface.blit(self.image,self.rect)

        return actine
        
