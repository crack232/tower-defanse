import pygame
import random

class Rounds:

    def __init__(self):
        self.level=1
        self.enemy_list=[]
        self.spawend_enemeis=0
        self.killed_enemeis=0
        self.missed_enemeis=0
        self.health=100
        self.game_speed=2
        self.money=400
        self.base= 5
        self.fast=2
        self.regane=1
        self.timer=0
        self.strong=2
        self.boss=0
        self.ballon_timer=50
        self.increse=0
        self.increse_timer=1
    
    def process_enemyis(self):
         
         enemyis={"base":self.base,"fast":self.fast,"strong":self.strong,"regane":self.regane,"boss":self.boss}


         for enemy_type in enemyis:
            enemeis_to_spawn=enemyis[enemy_type]
            for enemy in range(enemeis_to_spawn):
                self.enemy_list.append(enemy_type)
         #randomiz spawn order
         random.shuffle(self.enemy_list)
         self.boss=0
    
    def check_if_level_complete(self):
      if (self.killed_enemeis+self.missed_enemeis)==len(self.enemy_list):
        self.spawend_enemeis=0
        self.killed_enemeis=0
        self.missed_enemeis=0
        self.enemy_list=[]
        self.level+=1
        self.timer+=1
        self.base+=1
        self.increse_timer+=1
        if self.timer==2:
            self.fast+=1
            self.timer=0
            self.strong+=1
            self.regane+=1
        if self.increse_timer==10:
            self.increse+=3
            self.boss+=1
            if self.ballon_timer>10:
              self.ballon_timer-=10
            self.increse_timer=0
        self.process_enemyis()
        return True


    
    
    
